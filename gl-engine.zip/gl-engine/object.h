#ifndef OBJECT_H_
#define OBJECT_H_

#include <GL/glut.h>
#include "color.h"

class Object {
public:
  Object(double _x,double _y);
  Object(double _x,double _y, const Color& color_);
  void draw();

private:
  double x = 0;
  double y = 0;
  Color color;
};

#endif // OBJECT_H_
