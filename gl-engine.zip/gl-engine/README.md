//build
g++ -Wall -std=c++11 object.cpp main.cpp -o a.out -lGL -lglut -lGLU

