// g++ -Wall -std=c++11 object.cpp main.cpp -o a.out -lGL -lglut -lGLU

#include <iostream>
#include <vector>
#include <GL/glut.h>

#include "object.h"
#include "color.h"


std::vector<Object*> vect;

void Draw() {
 std::cout << "Draw" << std::endl;
 glClearColor(1.0,1.0,1.0,0.0);
 glClear(GL_COLOR_BUFFER_BIT);
 for(auto item : vect){
  item->draw();
 }
 glutSwapBuffers();
}


int main(int argc, char** argv) {

  glutInit(&argc,argv);
  glutInitDisplayMode(GLUT_RGBA|GLUT_DOUBLE);
  glutInitWindowSize(680,420);
  glutInitWindowPosition(300,100);
  glutCreateWindow("Figure");

  vect.push_back(new Object(0.5,0.5,Color(1.0,0.0,0.0)));
  vect.push_back(new Object(-0.3,0.3,Color(0.0,1.0,0.0)));

  glutDisplayFunc(Draw);
  glutMainLoop();

  return 0;
}
