#include "object.h"

Object::Object(double _x,double _y): x(_x), y(_y), color(0.0, 0.0, 0.0) {

}

Object::Object(double _x,double _y, const Color& color_): x(_x), y(_y), color(color_) {

}

void Object::draw() {
  glBegin(GL_TRIANGLES);
  glColor3f(color.r, color.g, color.b);
  glVertex3f(x-0.2,y-0.2,0.0);
  glVertex3f(x+0.1,y+0.5,0.0);
  glVertex3f(x+0.4,y-0.2,0.0);
  glEnd();
}

